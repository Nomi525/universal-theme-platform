-- AlterTable
ALTER TABLE "public"."DesignElementCatalog" ADD COLUMN     "settingsSchema" JSONB;
